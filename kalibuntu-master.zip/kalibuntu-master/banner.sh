#! /usr/bin/env bash

tput setaf 1
cat << "EOF"
    __ __      ___ __                __       
   / //_/___ _/ (_) /_  __  ______  / /___  __
  / ,< / __ `/ / / __ \/ / / / __ \/ __/ / / /
 / /| / /_/ / / / /_/ / /_/ / / / / /_/ /_/ / 
/_/ |_\__,_/_/_/_.___/\__,_/_/ /_/\__/\__,_/  

                By Funeoz        
    https://github.com/funeoz/kalibuntu

EOF
tput sgr0