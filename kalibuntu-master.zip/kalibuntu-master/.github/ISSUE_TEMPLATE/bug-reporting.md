---
name: Bug reporting
about: Use this to report a bug
title: ''
labels: bug
assignees: ''

---

1) When reporting an issue, please provide the `kalibuntu.log` file using pastebin or alternatives.

Note: The file is regenerated after each run of Kalibuntu. If you have run a new time Kalibuntu after the issue, please try to reproduce the error and provide the log file.

2) Give info about your system

OS: [eg. Kubuntu 18.04]
