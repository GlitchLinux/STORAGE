#!/usr/bin/env bash
#
# Copyright 2013 VMware, Inc.  All rights reserved.
#

SERIAL=$1
PRODUCT=$2
VERSION=$3

ETCDIR=/etc/vmware
. $ETCDIR/bootstrap

libdir="$LIBDIR"/vmware

${libdir}/bin/licenseTool check "${SERIAL}" "${VERSION}" "${PRODUCT}" ${libdir} | grep '^200' >/dev/null

